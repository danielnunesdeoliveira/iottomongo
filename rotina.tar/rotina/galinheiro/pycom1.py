import time
import ttn
import pymongo


app_id = "123pycom"
access_key = "ttn-account-v2.I71FP0EcbX5qayE7LyJX2heIuGj2TOOkfIZM6YB9QGI"
sensor=[]

def uplink_callback(msg, client):
  print("Received uplink from ", msg.dev_id)
  print(msg)
  sensor=msg
  print(sensor[3]) # payload na BASE64
  client = pymongo.MongoClient("mongodb://micaelli:XTP9ZxcijvACGx79@cluster0-shard-00-00-z3s5g.mongodb.net:27017,cluster0-shard-00-01-z3s5g.mongodb.net:27017,cluster0-shard-00-02-z3s5g.mongodb.net:27017/<dbname>?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority")
  db = client.galinheiro1
  collection=db.pycom       ## VARIAVEL ##
  posts=db.pycom123
  postid=posts.insert_one({"pycom1": sensor[3]}).inserted_id

handler = ttn.HandlerClient(app_id, access_key)
# using mqtt client
mqtt_client = handler.data()
mqtt_client.set_uplink_callback(uplink_callback)
mqtt_client.connect()
time.sleep(600)
mqtt_client.close()

