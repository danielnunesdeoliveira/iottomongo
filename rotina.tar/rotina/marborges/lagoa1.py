import requests # http resposta
import json     # retorno api Aikido e add infor. on DBMONGO
#from jsonmerge import merge # unir pacotes json (original retorno aikido + incremento)
import datetime

# Python na versao 27

# DECLARACOES
url = "http://188.166.108.52:8000/auth" 
uri = "http://188.166.108.52:8000/history/device/361287/history?lastN=1"   ## VARIAVEL ##
headersp = {'Content-Type': "application/json"}
permissao = {"username": "admin", "passwd": "admin"}
#------------------------

# REQUSICAO TOKEN
res = requests.post(url,json=permissao, headers=headersp)
x = res.text # realmente, aqui  um json
y = json.loads(x)
a = y["jwt"]
#print(a)
#---------------

# PASSAR A AUTORIZACAO DE USO DA API E RESGATAR O VALOR
headersg = {'Content-Type':"application/json",'Authorization':"Bearer "+a}
res2 = requests.get(uri,headers=headersg)
#print(res2.text)
x1 = res2.text
y1 = json.loads(x1)
'''print("y1")
print(y1)
print("-----------------")
print ("y1[varoxigenio]")
print (y1["varoxigenio"])
print("-----------------")
print("ts")
print(y1["varoxigenio"][0]['ts'])
print("-----------------")
'''
#-----------------------------

# CORRECAO DO FUSO HORARIO UTC
y1ts=y1["cgenv"][0]["ts"]              ## VARIAVEL ##  y1ts=y1["varoxigenio"][0]['ts']              ## VARIAVEL ##
fuso=3 # Fuso horario brasilia  ## VARIAVEL ##
'''print ("y1ts")
print(y1ts)
print("-----------------")
print ("data:")
'''
data=y1ts[:19]   # posicao da data (0, 19) ddmmaaTH:M:S
'''print (data)
print("--------------")
print("hora:")
'''
horau=int(y1ts[12]) # Unidade da Hora
horad=int(y1ts[11])  # Dezena da Hora
'''print ("unidade")
print(horau)
print ("dezena")
print(horad)
'''
horautc=horad*10+horau  ## valor inteiro da Hora para ser manipulado
#print("horario brasilia")
horabr=horautc - fuso # valor inteiro, Hora para  fuso de brasilia
#print(horac)
jshora1='{"horac": '
jshora2='}'
jshorabr=jshora1+str(horabr)+jshora2 # string
'''print ("json hora")
print(hora)
'''
phorabr=json.loads(jshorabr) # python objeto
'''print(horaf)
print ("json minuto")
'''
minbr=y1ts[14:16]
jsmin1='{"minuc": '
jsmin2='}'
jsminbr=jsmin1+minbr+jsmin2
#print(min)
#minf=json.loads(min)   #python objeto
#print(minf)
#print("hora+minuto")
#hm= str(horac)+':'+ minc
strhorabr=str(horabr)+'h'+minbr+'m' # exemplo: 13h32m
#print("hm")
#print(hm)
#print("------------")
dataano=y1ts[0:4]  # ano
#print("ano")
#print(datac1)
datames= y1ts[5:7] # mes
#print("mes")
#print(datac2)
datadia=y1ts[8:10] # dia
#print("dia")
#print(datac3)
jsdata1='{"datac": '
jsdata2='}'
#data3=data1+datac3+datac2+datac1+hm+data2 #string somente numeros
#data3 = data1+datac1+datac3+datac2+" "+hm+data2 # ideal, mas problema, pois nao reconhece o 'T' e nem ':'
strdatabr='"'+dataano+datadia+datames+" "+strhorabr+'"'
#print("strdatabr")
#print(strdatabr)
jsdatabr=jsdata1+strdatabr+jsdata2
#print(data33)
#print("loads")
pdatabr=json.loads(jsdatabr)
#print(pdatabr)

# -------------------------------------------

# FUNCAO MERGE, UNIR TODOS OS JSON SEPARADOR EM UM SO

#datacom=merge(y1,pdatabr)
datacom=y1
#dfinal=merge(datacom,y1varoxigeniocorrigjson)
'''print("dado completo")
print(datacom2)
'''
#--------------------------------

# PUBLICACAO DOS DADOS EM UM CLUSTER MONGODB
import pymongo

client = pymongo.MongoClient("mongodb://maikel:1Amigao@cluster1-shard-00-00-gzl0t.azure.mongodb.net:27017,cluster1-shard-00-01-gzl0t.azure.mongodb.net:27017,cluster1-shard-00-02-gzl0t.azure.mongodb.net:27017/test?ssl=true&replicaSet=Cluster1-shard-0&authSource=admin&retryWrites=true&w=majority")
db = client.marborges                          ## VARIAVEL ##
collection=db.lagoa        ## VARIAVEL ##
posts=db.lagoat                       ## VARIAVEL ##
#post = y1
#postid=posts.insert_one(datacom2).inserted_id

flag = 0
for k in posts.find(datacom):
        flag=1
       # print (flag)
if flag == 1:
         print ("Dado existe")
        # print(y1varoxigenio)
else:
  postid=posts.insert_one(datacom).inserted_id
  print("Adiciona dado")


