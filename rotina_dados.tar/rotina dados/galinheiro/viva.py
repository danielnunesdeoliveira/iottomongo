import time
import ttn
import pymongo


app_id = "123pycom"
access_key = "ttn-account-v2.I71FP0EcbX5qayE7LyJX2heIuGj2TOOkfIZM6YB9QGI"

def uplink_callback(msg, client):
  print("Received uplink from ", msg.dev_id)
  print(msg)
  print("-----------------")
  print("mensagem crua")
  print(msg[3]) # payload_raw na BASE64
  import base64
  encoded = msg[3]
  payload = base64.b64decode(encoded)
  print("mensagem publicada")
  client = pymongo.MongoClient("mongodb://galinheiro:uuHgnom5KDYph3o2@cluster0-shard-00-00-zfxkw.mongodb.net:27017,cluster0-shard-00-01-zfxkw.mongodb.net:27017,cluster0-shard-00-02-zfxkw.mongodb.net:27017/<dbname>?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority")
  db = client.test
  #client = pymongo.MongoClient("mongodb://galinheiro:uuHgnom5KDYph3o2@cluster0-shard-00-00-zfxkw.mongodb.net:27017,cluster0-shard-00-01-zfxkw.mongodb.net:27017,cluster0-shard-00-02-zfxkw.mongodb.net:27017/ninho?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority")
  #db=client.ninho
  collection=db.pycom       ## VARIAVEL ##
  posts=db.temp
 # postid=posts.insert_one({"payload_temp": payload, "gtw_id": gtw_id, "gtw_rssi": gtw_rssi, "time": time }).inserted_id
  postid=posts.insert_one({"oi": 2})

handler = ttn.HandlerClient(app_id, access_key)
# using mqtt client
mqtt_client = handler.data()
mqtt_client.set_uplink_callback(uplink_callback)
mqtt_client.connect()
time.sleep(60)
mqtt_client.close()

