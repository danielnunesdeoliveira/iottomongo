
import pymongo

  client = pymongo.MongoClient("mongodb://galinheiro:uuHgnom5KDYph3o2@cluster0-shard-00-00-zfxkw.mongodb.net:27017,cluster0-shard-00-01-zfxkw.mongodb.net:27017,cluster0-shard-00-02-zfxkw.mongodb.net:27017/ninho?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority")
  db = client.ninho
  collection=db.pycom       ## VARIAVEL ##
  posts=db.temp
 # postid=posts.insert_one({"payload_temp": payload, "gtw_id": gtw_id, "gtw_rssi": gtw_rssi, "time": time }).inserted_id
  postid=posts.insert_one({"oi": 2})

