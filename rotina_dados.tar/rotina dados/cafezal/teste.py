import pymongo
client = pymongo.MongoClient("mongodb://cafezal:boKvdgHPajuyueHU@cluster0-shard-00-00.ncrwx.mongodb.net:27017,cluster0-shard-00-01.ncrwx.mongodb.net:27017,cluster0-shard-00-02.ncrwx.mongodb.net:27017/<dbname>?ssl=true&replicaSet=atlas-12fq9p-shard-0&authSource=admin&retryWrites=true&w=majority")                              
db=client.cafezal
collection=db.secagem      ## VARIAVEL ##
posts=db.secagem1
postid=posts.insert_one({"payload_temp": 1})
