import requests # http resposta
import json     # retorno api Aikido e add infor. on DBMONGO
import datetime

# Python na versao 27

# DECLARACOES
url = "http://157.245.79.47:8000/auth" 
uri = "http://157.245.79.47:8000/history/device/bd1626/history?lastN=1"   ## VARIAVEL ##
headersp = {'Content-Type': "application/json"}
permissao = {"username": "admin", "passwd": "AmazingRick&29"}
#------------------------

# REQUSICAO TOKEN
res = requests.post(url,json=permissao, headers=headersp)
x = res.text # realmente, aqui  um json
y = json.loads(x)
a = y["jwt"]
#print(a)
#---------------

# PASSAR A AUTORIZACAO DE USO DA API E RESGATAR O VALOR
headersg = {'Content-Type':"application/json",'Authorization':"Bearer "+a}
res2 = requests.get(uri,headers=headersg)
#print(res2.text)
x1 = res2.text
y1 = json.loads(x1)

# PUBLICACAO DOS DADOS EM UM CLUSTER MONGODB
import pymongo

client = pymongo.MongoClient("mongodb://maikel:1Amigao@cluster3-shard-00-00.gzl0t.mongodb.net:27017,cluster3-shard-00-01.gzl0t.mongodb.net:27017,cluster3-shard-00-02.gzl0t.mongodb.net:27017/test?ssl=true&replicaSet=atlas-be6tzi-shard-0&authSource=admin&retryWrites=true&w=majority")
db = client.marborges                          ## VARIAVEL ##
collection=db.phetemp       ## VARIAVEL ##
posts=db.lagoa                      ## VARIAVEL ##

flag = 0
for k in posts.find(y1):
        flag=1
       # print (flag)
if flag == 1:
         print ("Dado existe")
        # print(y1varoxigenio)
else:
  postid=posts.insert_one(y1).inserted_id
  print("Adiciona dado")

